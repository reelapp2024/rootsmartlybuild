
import React, { useEffect, useState, useLayoutEffect, lazy, Suspense } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Calendar } from 'lucide-react';
import { Helmet, HelmetProvider } from 'react-helmet-async';

import { Phone, Clock, Star, Shield, Award, CheckCircle, Zap, Users, Wrench } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '../components/Header';
import HeroSection from '../components/HeroSection';
import AboutSection from '../components/AboutSection';
import ServicesSection from '../components/ServicesSection';
import Footer from '../components/Footer';
import SEOHead from '../components/SEOHead';
import { httpFile } from "../../../config.js";
import { useSEO } from '../../../hooks/useSEO';
import DynamicIcon from '../../../extras/DynamicIcon.js';
import { useTheme } from '../contexts/ThemeContext';
import Loader from '../components/Loader';

// Lazy load heavy components
const BookingSection = lazy(() => import('../components/BookingSection'));
const WhyChooseUsSection = lazy(() => import('../components/WhyChooseUsSection'));
const ProcessSection = lazy(() => import('../components/ProcessSection'));
const TestimonialsSection = lazy(() => import('../components/TestimonialsSection'));
const GuaranteeSection = lazy(() => import('../components/GuaranteeSection'));
const AreasSection = lazy(() => import('../components/AreasSection'));
const FAQSection = lazy(() => import('../components/FAQSection'));
const SchemaMarkup = lazy(() => import('../components/SchemaMarkup'));
const PageSchemaMarkup = lazy(() => import('../components/PageSchemaMarkup'));
const TestimonialsSchemaMarkup = lazy(() => import('../components/TestimonialsSchemaMarkup'));
const ProcessSchemaMarkup = lazy(() => import('../components/ProcessSchemaMarkup'));
const WebVitals = lazy(() => import('../components/WebVitals'));

interface Feature {
  serialno: number;
  iconName: string;
  title: string;
  subtitle: string;
}



const Index = () => {

  const { seoData } = useSEO('/home');
  const { getThemeColors } = useTheme();
  const colors = getThemeColors();
  const [projectCategory, setProjectCategory] = useState("");
  const [CTA, setCTA] = useState([]);
  const projectId = import.meta.env.VITE_PROJECT_ID;
  const location = useLocation();
  const navigate = useNavigate();
  const [phoneNumber, setPhoneNumber] = useState("");
  const [backgroundImage, setBackgroundImage] = useState("");


  const [welcomeLine, setWelcomeLine] = useState('');
  const [projectSlogan, setProjectSlogan] = useState('');

  let [features, setFeatures] = useState<Feature[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [heroHeadingPart1, setHeroHeadingPart1] = useState('');
  const [heroHeadingPart2, setHeroHeadingPart2] = useState('');
  const conjunctions = [
    'and', 'or', 'but', 'with', 'for', 'as', 'because', 'so', 'then', 'by', 'on', 'at',
    'in', 'of', 'to', 'from', 'about', 'through', 'between', 'during', 'before', 'after'
  ];


  useEffect(() => {
    (async () => {
      try {
        const { data } = await httpFile.post('/webapp/v1/my_site', {
          projectId,
          pageType: 'home',
          reqFrom: 'Hero'
        });

        const info = data.projectInfo || {};
        const about = data.aboutUs || {};
        setCTA(info.cta);
        setBackgroundImage(info.images?.[2]?.url || "");

        setProjectCategory(info.serviceType || '');
        setWelcomeLine(info.welcomeLine || '');
        setPhoneNumber(about.phone || '');
        // Split heroHeading intelligently
        const words = info.heroHeading?.split(' ') || [];

        // If heading has more than 3 words, attempt to split based on meaningful conjunctions
        if (words.length > 3) {
          let breakIndex = -1;
          // Find the first occurrence of any conjunction or preposition
          for (let i = 0; i < words.length; i++) {
            if (conjunctions.includes(words[i].toLowerCase())) {
              breakIndex = i;
              break;
            }
          }

          if (breakIndex !== -1) {
            // Split at the first meaningful conjunction
            setHeroHeadingPart1(words.slice(0, breakIndex + 1).join(' ') || '');
            setHeroHeadingPart2(words.slice(breakIndex + 1).join(' ') || '');
          } else {
            // Fallback to split the first part with a few words, and second part with the rest
            setHeroHeadingPart1(words.slice(0, words.length - 2).join(' ') || '');
            setHeroHeadingPart2(words.slice(-2).join(' ') || '');
          }
        } else {
          // For 2 or 3 words, use a simpler split
          if (words.length === 3) {
            setHeroHeadingPart1(words.slice(0, 1).join(' ') || '');
            setHeroHeadingPart2(words.slice(1).join(' ') || '');
          } else {
            setHeroHeadingPart1(words.slice(0, 1).join(' ') || '');
            setHeroHeadingPart2(words.slice(1).join(' ') || '');
          }
        }

        setProjectSlogan(info.projectSlogan || `Professional ${info.serviceType}`);
        // sanitize helper
        const strip = (s: any) =>
          typeof s === 'string'
            ? s.trim().replace(/^[,\"\s]+|[,\"\s]+$/g, '')
            : '';

        // clean features

        // No more hardcoded classArray - we'll use theme colors dynamically
        const modifiedFeatures = (info.featuresSection || []).map((f, index) => ({
          serialno: f.serialno,
          iconName: strip(f.iconName),
          title: strip(f.title),
          subtitle: strip(f.subtitle),
        }));

        setFeatures(modifiedFeatures);

      } catch (err) {
        console.error('Fetch hero data error:', err);
      } finally {
        setIsLoading(false);
      }
    })();
  }, [projectId]);
  // Example API fetch and modification

  const getCTAContent = (index) => {
    if (CTA.length === 0) {
      return { title: "What are you waiting for?", description: "Contact us for our services" };
    }
    return CTA[index] || CTA[0];
  };



  if (isLoading) {
    return <Loader message="Loading Home Page..." variant="elegant" size="lg" />;
  }

  return (
    <HelmetProvider>
      <div className="min-h-screen font-poppins">
        <Helmet>
          <title>{seoData.meta_title}</title>
          <meta name="description" content={seoData.meta_description} />
          <meta name="keywords" content={seoData.meta_keywords} />
        </Helmet>
        <WebVitals />
        <SchemaMarkup />
        <PageSchemaMarkup
          pageType="home"
          pageTitle={seoData.meta_title}
          pageDescription={seoData.meta_description}
        />
        {/* <TestimonialsSchemaMarkup /> */}
        <ProcessSchemaMarkup />
        <Header />
        {/* Hero section */}


        {/* Modern Hero Section - Redesigned */}
        <section
          id="home"
          className="relative min-h-screen flex items-center overflow-hidden"
          style={{
            background: `linear-gradient(135deg, ${colors.gradient.from} 0%, ${colors.gradient.to} 100%)`
          }}
        >
          {/* Background Image with Overlay */}
          {backgroundImage && (
            <>
              <div 
                className="absolute inset-0 opacity-20"
                style={{
                  backgroundImage: `url(${backgroundImage})`,
                  backgroundSize: 'cover',
                  backgroundPosition: 'center',
                  backgroundRepeat: 'no-repeat'
                }}
              ></div>
              <div 
                className="absolute inset-0"
                style={{
                  backgroundColor: colors.overlay.color
                }}
              ></div>
            </>
          )}
          
          {/* Animated Grid Pattern */}
          <div className="absolute inset-0 opacity-5">
            <div className="absolute inset-0" style={{
              backgroundImage: `linear-gradient(${colors.primaryButton.bg} 1px, transparent 1px), linear-gradient(90deg, ${colors.primaryButton.bg} 1px, transparent 1px)`,
              backgroundSize: '50px 50px'
            }}></div>
          </div>

          {/* Floating Orbs */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div 
              className="absolute top-20 left-10 w-32 h-32 rounded-full blur-3xl animate-pulse"
              style={{ 
                backgroundColor: colors.primaryButton.bg,
                opacity: 0.15,
                animationDelay: '0s'
              }}
            ></div>
            <div 
              className="absolute bottom-20 right-20 w-40 h-40 rounded-full blur-3xl animate-pulse"
              style={{ 
                backgroundColor: colors.accent,
                opacity: 0.1,
                animationDelay: '2s'
              }}
            ></div>
            <div 
              className="absolute top-1/2 left-1/3 w-24 h-24 rounded-full blur-2xl animate-pulse"
              style={{ 
                backgroundColor: colors.primaryButton.bg,
                opacity: 0.12,
                animationDelay: '4s'
              }}
            ></div>
          </div>

          <div className="container mx-auto px-4 sm:px-6 lg:px-8 xl:px-16 relative z-10 py-20">
            <div className="grid lg:grid-cols-2 gap-12 items-center max-w-7xl mx-auto">
              
              {/* Left Content */}
              <div className="space-y-8 text-center lg:text-left animate-fade-in">
                
                {/* Badge with Animation */}
                <div className="inline-flex items-center gap-3 group">
                  <div 
                    className="relative px-6 py-3 rounded-full backdrop-blur-md transition-all duration-300 group-hover:scale-105"
                    style={{
                      backgroundColor: `${colors.primaryButton.bg}15`,
                      border: `2px solid ${colors.primaryButton.bg}30`,
                      boxShadow: `0 0 20px ${colors.primaryButton.bg}20`
                    }}
                  >
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-2.5 h-2.5 rounded-full animate-pulse"
                        style={{ backgroundColor: colors.primaryButton.bg }}
                      ></div>
                      <span 
                        className="font-bold text-sm tracking-wider uppercase"
                        style={{ color: colors.heading }}
                      >
                        {projectSlogan}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Main Heading - Enhanced */}
                <div className="space-y-4">
                  <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-black leading-[1.05] tracking-tight">
                    <span 
                      className="block"
                      style={{ color: colors.heading }}
                    >
                      {heroHeadingPart1}
                    </span>
                    <span 
                      className="block mt-2 bg-clip-text text-transparent"
                      style={{
                        backgroundImage: `linear-gradient(135deg, ${colors.primaryButton.bg} 0%, ${colors.accent} 100%)`,
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent'
                      }}
                    >
                      {heroHeadingPart2}
                    </span>
                  </h1>
                </div>

                {/* Subheading - Enhanced */}
                <p 
                  className="text-lg sm:text-xl md:text-2xl max-w-2xl mx-auto lg:mx-0 leading-relaxed font-medium"
                  style={{ color: colors.description }}
                >
                  {welcomeLine}
                </p>

                {/* CTA Buttons - Enhanced Design */}
                <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start pt-2">
                  
                  {/* Call Button - Premium Design */}
                  <a
                    href={`tel:${phoneNumber}`}
                    className="group relative inline-flex items-center gap-4 px-8 py-5 rounded-2xl font-bold text-lg transition-all duration-300 hover:scale-105 hover:shadow-2xl"
                    style={{
                      backgroundColor: colors.primaryButton.bg,
                      color: colors.primaryButton.text,
                      boxShadow: `0 10px 40px ${colors.primaryButton.bg}40`
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = colors.primaryButton.hover;
                      e.currentTarget.style.transform = 'scale(1.05)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = colors.primaryButton.bg;
                      e.currentTarget.style.transform = 'scale(1)';
                    }}
                  >
                    <div className="relative">
                      <Phone className="w-6 h-6" />
                      <div 
                        className="absolute -top-1 -right-1 w-3 h-3 rounded-full animate-pulse"
                        style={{ backgroundColor: '#22C55E' }}
                      ></div>
                    </div>
                    <div className="text-left">
                      <div className="text-xs font-semibold opacity-90 uppercase tracking-wider">Call Now</div>
                      <div className="text-base font-black">{phoneNumber}</div>
                    </div>
                    <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" style={{
                      background: `linear-gradient(135deg, ${colors.primaryButton.bg}, ${colors.accent})`
                    }}></div>
                  </a>

                  {/* Get Estimate Button - Premium Design */}
                  <button
                    onClick={() => navigate('/contact')}
                    className="group relative inline-flex items-center justify-center gap-3 px-8 py-5 rounded-2xl font-bold text-lg transition-all duration-300 hover:scale-105 backdrop-blur-md"
                    style={{
                      backgroundColor: `${colors.secondaryButton.bg === 'transparent' ? 'rgba(255,255,255,0.1)' : colors.secondaryButton.bg}`,
                      color: colors.secondaryButton.text,
                      border: `2px solid ${colors.secondaryButton.border}`,
                      boxShadow: `0 10px 40px ${colors.secondaryButton.border}20`
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = colors.secondaryButton.hover;
                      e.currentTarget.style.borderColor = colors.primaryButton.bg;
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = colors.secondaryButton.bg === 'transparent' ? 'rgba(255,255,255,0.1)' : colors.secondaryButton.bg;
                      e.currentTarget.style.borderColor = colors.secondaryButton.border;
                    }}
                  >
                    <Wrench className="w-6 h-6" />
                    <span>Get Free Estimate</span>
                  </button>
                </div>

                {/* Trust Indicators - Enhanced */}
                <div 
                  className="flex flex-wrap items-center justify-center lg:justify-start gap-6 pt-6"
                  style={{ color: colors.description }}
                >
                  <div 
                    className="flex items-center gap-3 px-4 py-2 rounded-xl backdrop-blur-sm transition-all duration-300 hover:scale-105"
                    style={{
                      backgroundColor: `${colors.primaryButton.bg}10`,
                      border: `1px solid ${colors.primaryButton.bg}20`
                    }}
                  >
                    <Shield 
                      className="w-5 h-5" 
                      style={{ color: colors.accent }}
                    />
                    <span className="text-sm font-semibold">Licensed & Insured</span>
                  </div>
                  <div 
                    className="flex items-center gap-3 px-4 py-2 rounded-xl backdrop-blur-sm transition-all duration-300 hover:scale-105"
                    style={{
                      backgroundColor: `${colors.primaryButton.bg}10`,
                      border: `1px solid ${colors.primaryButton.bg}20`
                    }}
                  >
                    <Star 
                      className="w-5 h-5 fill-current" 
                      style={{ color: colors.accent }}
                    />
                    <span className="text-sm font-semibold">5-Star Rated</span>
                  </div>
                  <div 
                    className="flex items-center gap-3 px-4 py-2 rounded-xl backdrop-blur-sm transition-all duration-300 hover:scale-105"
                    style={{
                      backgroundColor: `${colors.primaryButton.bg}10`,
                      border: `1px solid ${colors.primaryButton.bg}20`
                    }}
                  >
                    <Clock 
                      className="w-5 h-5" 
                      style={{ color: colors.accent }}
                    />
                    <span className="text-sm font-semibold">24/7 Available</span>
                  </div>
                </div>

              </div>

              {/* Right Visual - Stats Cards */}
              <div className="hidden lg:grid grid-cols-2 gap-6 animate-fade-in-delay">
                {/* Stat Card 1 */}
                <div 
                  className="p-6 rounded-3xl backdrop-blur-md transition-all duration-300 hover:scale-105 hover:-translate-y-2"
                  style={{
                    backgroundColor: `${colors.primaryButton.bg}15`,
                    border: `2px solid ${colors.primaryButton.bg}30`,
                    boxShadow: `0 20px 60px ${colors.primaryButton.bg}20`
                  }}
                >
                  <div className="text-center space-y-2">
                    <div 
                      className="text-4xl font-black"
                      style={{ color: colors.primaryButton.bg }}
                    >
                      10K+
                    </div>
                    <div 
                      className="text-sm font-semibold"
                      style={{ color: colors.description }}
                    >
                      Happy Customers
                    </div>
                  </div>
                </div>

                {/* Stat Card 2 */}
                <div 
                  className="p-6 rounded-3xl backdrop-blur-md transition-all duration-300 hover:scale-105 hover:-translate-y-2"
                  style={{
                    backgroundColor: `${colors.accent}15`,
                    border: `2px solid ${colors.accent}30`,
                    boxShadow: `0 20px 60px ${colors.accent}20`
                  }}
                >
                  <div className="text-center space-y-2">
                    <div 
                      className="text-4xl font-black"
                      style={{ color: colors.accent }}
                    >
                      24/7
                    </div>
                    <div 
                      className="text-sm font-semibold"
                      style={{ color: colors.description }}
                    >
                      Available Service
                    </div>
                  </div>
                </div>

                {/* Stat Card 3 */}
                <div 
                  className="p-6 rounded-3xl backdrop-blur-md transition-all duration-300 hover:scale-105 hover:-translate-y-2"
                  style={{
                    backgroundColor: `${colors.primaryButton.bg}15`,
                    border: `2px solid ${colors.primaryButton.bg}30`,
                    boxShadow: `0 20px 60px ${colors.primaryButton.bg}20`
                  }}
                >
                  <div className="text-center space-y-2">
                    <div 
                      className="text-4xl font-black"
                      style={{ color: colors.primaryButton.bg }}
                    >
                      5★
                    </div>
                    <div 
                      className="text-sm font-semibold"
                      style={{ color: colors.description }}
                    >
                      Average Rating
                    </div>
                  </div>
                </div>

                {/* Stat Card 4 */}
                <div 
                  className="p-6 rounded-3xl backdrop-blur-md transition-all duration-300 hover:scale-105 hover:-translate-y-2"
                  style={{
                    backgroundColor: `${colors.accent}15`,
                    border: `2px solid ${colors.accent}30`,
                    boxShadow: `0 20px 60px ${colors.accent}20`
                  }}
                >
                  <div className="text-center space-y-2">
                    <div 
                      className="text-4xl font-black"
                      style={{ color: colors.accent }}
                    >
                      15+
                    </div>
                    <div 
                      className="text-sm font-semibold"
                      style={{ color: colors.description }}
                    >
                      Years Experience
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* Bottom Wave - Enhanced */}
          <div className="absolute bottom-0 left-0 right-0">
            <svg className="w-full h-20 md:h-32" viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
              <path 
                d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z" 
                fill="currentColor" 
                className="text-background"
              />
            </svg>
          </div>
        </section>

        <AboutSection />

        {/* Features Section - After About */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4 sm:px-8 lg:px-16">
            {/* Cards Grid */}
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
              {features.map((f, index) => {
                return (
                  <div
                    key={index}
                    className="group relative bg-white rounded-3xl p-8 transition-all duration-500 hover:-translate-y-2 shadow-lg hover:shadow-2xl"
                    style={{
                      border: `1px solid ${colors.primaryButton.bg}15`
                    }}
                  >
                    {/* Hover Border Effect */}
                    <div 
                      className="absolute inset-0 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                      style={{
                        border: `2px solid ${colors.primaryButton.bg}40`,
                        boxShadow: `0 0 20px ${colors.primaryButton.bg}20`
                      }}
                    ></div>

                    {/* Content */}
                    <div className="relative space-y-5">
                      {/* Icon Container */}
                      <div className="w-fit">
                        <div 
                          className="w-16 h-16 rounded-2xl flex items-center justify-center transition-all duration-500 group-hover:scale-110"
                          style={{
                            backgroundColor: `${colors.primaryButton.bg}15`,
                            border: `2px solid ${colors.primaryButton.bg}30`
                          }}
                        >
                          <DynamicIcon
                            iconName={f.iconName}
                            className="w-8 h-8 transition-transform duration-500 group-hover:rotate-12"
                            style={{ color: colors.primaryButton.bg }}
                          />
                        </div>
                      </div>

                      {/* Text Content */}
                      <div className="space-y-3">
                        <h3 
                          className="text-xl font-bold leading-tight text-gray-900"
                        >
                          {f.title}
                        </h3>
                        <p 
                          className="text-base leading-relaxed text-gray-600"
                        >
                          {f.subtitle}
                        </p>
                      </div>

                      {/* Bottom Accent Line */}
                      <div 
                        className="h-1 rounded-full transition-all duration-500 group-hover:w-full"
                        style={{
                          width: '3rem',
                          background: `linear-gradient(90deg, ${colors.primaryButton.bg}, ${colors.accent})`
                        }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        <ServicesSection />
        {/* <BookingSection />*/}

        <section 
          className="py-16 relative overflow-hidden"
          style={{
            background: `linear-gradient(135deg, ${colors.gradient.from}, ${colors.gradient.to})`
          }}
        >
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-10 left-10 w-20 h-20 rounded-full animate-pulse" style={{ backgroundColor: colors.accent }}></div>
            <div className="absolute bottom-10 right-10 w-16 h-16 rounded-full animate-pulse" style={{ animationDelay: '1s', backgroundColor: colors.primaryButton.bg }}></div>
            <div className="absolute top-1/2 left-1/3 w-12 h-12 rounded-full animate-pulse" style={{ animationDelay: '2s', backgroundColor: colors.accent }}></div>
          </div>

          <div className="container mx-auto px-4 sm:px-8 lg:px-16 text-center relative z-10">
            
            {/* Section Header */}
            <div className="mb-8">
              <h2 className="text-lg sm:text-xl md:text-2xl font-bold text-white mb-4 max-w-2xl mx-auto leading-tight">
                {getCTAContent(1).title}
              </h2>
              <p className="text-xs sm:text-sm text-white/90 max-w-2xl mx-auto leading-relaxed">
                {getCTAContent(1).description}
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
              
              {/* Call Button */}
              <a
                href={`tel:${phoneNumber}`}
                className="group relative inline-flex items-center gap-3 px-6 py-4 rounded-xl font-semibold text-base transition-all duration-300 hover:-translate-y-1 shadow-lg"
                style={{
                  backgroundColor: colors.primaryButton.bg,
                  color: colors.primaryButton.text
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = colors.primaryButton.hover}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = colors.primaryButton.bg}
              >
                <div className="relative">
                  <Phone className="w-5 h-5" />
                  <div className="absolute -top-1 -right-1 w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                </div>
                <div className="text-left">
                  <div className="text-xs font-semibold opacity-90 uppercase tracking-wide">Emergency Call</div>
                  <div className="text-sm font-bold">{phoneNumber}</div>
                </div>
              </a>

              {/* Book Online Button */}
              <Link
                to="/contact"
                className="group relative inline-flex items-center gap-3 px-6 py-4 rounded-xl font-semibold text-base transition-all duration-300 hover:-translate-y-1 shadow-lg backdrop-blur-md"
                style={{
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  color: colors.primaryButton.bg,
                  border: `2px solid ${colors.primaryButton.bg}30`
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = colors.primaryButton.bg;
                  e.currentTarget.style.color = colors.primaryButton.text;
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.95)';
                  e.currentTarget.style.color = colors.primaryButton.bg;
                }}
              >
                <Calendar className="w-5 h-5" />
                <div className="text-left">
                  <div className="text-xs font-semibold opacity-90 uppercase tracking-wide">Book Online</div>
                  <div className="text-sm font-bold">Schedule Service</div>
                </div>
              </Link>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap justify-center gap-6 text-white/90">
              <div className="flex items-center gap-2">
                <div 
                  className="w-2 h-2 rounded-full animate-pulse"
                  style={{ backgroundColor: colors.accent }}
                ></div>
                <span className="text-xs font-semibold">24/7 Available</span>
              </div>
              <div className="flex items-center gap-2">
                <div 
                  className="w-2 h-2 rounded-full animate-pulse"
                  style={{ backgroundColor: colors.primaryButton.bg }}
                ></div>
                <span className="text-xs font-semibold">Licensed & Insured</span>
              </div>
              <div className="flex items-center gap-2">
                <div 
                  className="w-2 h-2 rounded-full animate-pulse"
                  style={{ backgroundColor: colors.accent }}
                ></div>
                <span className="text-xs font-semibold">Same Day Service</span>
              </div>
            </div>
          </div>
        </section>



        <WhyChooseUsSection />
        <ProcessSection />
        {/* <BookingSection /> */}

        <section 
          className="py-16 relative overflow-hidden"
          style={{
            background: `linear-gradient(135deg, ${colors.gradient.from}, ${colors.gradient.to})`
          }}
        >
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-10 left-10 w-20 h-20 rounded-full animate-pulse" style={{ backgroundColor: colors.accent }}></div>
            <div className="absolute bottom-10 right-10 w-16 h-16 rounded-full animate-pulse" style={{ animationDelay: '1s', backgroundColor: colors.primaryButton.bg }}></div>
            <div className="absolute top-1/2 left-1/3 w-12 h-12 rounded-full animate-pulse" style={{ animationDelay: '2s', backgroundColor: colors.accent }}></div>
          </div>

          <div className="container mx-auto px-4 sm:px-8 lg:px-16 text-center relative z-10">
            
            {/* Section Header */}
            <div className="mb-8">
              <h2 className="text-lg sm:text-xl md:text-2xl font-bold text-white mb-4 max-w-2xl mx-auto leading-tight">
                {getCTAContent(2).title}
              </h2>
              <p className="text-xs sm:text-sm text-white/90 max-w-2xl mx-auto leading-relaxed">
                {getCTAContent(2).description}
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
              
              {/* Call Button */}
              <a
                href={`tel:${phoneNumber}`}
                className="group relative inline-flex items-center gap-3 px-6 py-4 rounded-xl font-semibold text-base transition-all duration-300 hover:-translate-y-1 shadow-lg"
                style={{
                  backgroundColor: colors.primaryButton.bg,
                  color: colors.primaryButton.text
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = colors.primaryButton.hover}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = colors.primaryButton.bg}
              >
                <div className="relative">
                  <Phone className="w-5 h-5" />
                  <div className="absolute -top-1 -right-1 w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                </div>
                <div className="text-left">
                  <div className="text-xs font-semibold opacity-90 uppercase tracking-wide">Emergency Call</div>
                  <div className="text-sm font-bold">{phoneNumber}</div>
                </div>
              </a>

              {/* Book Online Button */}
              <Link
                to="/contact"
                className="group relative inline-flex items-center gap-3 px-6 py-4 rounded-xl font-semibold text-base transition-all duration-300 hover:-translate-y-1 shadow-lg backdrop-blur-md"
                style={{
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  color: colors.primaryButton.bg,
                  border: `2px solid ${colors.primaryButton.bg}30`
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = colors.primaryButton.bg;
                  e.currentTarget.style.color = colors.primaryButton.text;
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.95)';
                  e.currentTarget.style.color = colors.primaryButton.bg;
                }}
              >
                <Calendar className="w-5 h-5" />
                <div className="text-left">
                  <div className="text-xs font-semibold opacity-90 uppercase tracking-wide">Book Online</div>
                  <div className="text-sm font-bold">Schedule Service</div>
                </div>
              </Link>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap justify-center gap-6 text-white/90">
              <div className="flex items-center gap-2">
                <div 
                  className="w-2 h-2 rounded-full animate-pulse"
                  style={{ backgroundColor: colors.accent }}
                ></div>
                <span className="text-xs font-semibold">24/7 Available</span>
              </div>
              <div className="flex items-center gap-2">
                <div 
                  className="w-2 h-2 rounded-full animate-pulse"
                  style={{ backgroundColor: colors.primaryButton.bg }}
                ></div>
                <span className="text-xs font-semibold">Licensed & Insured</span>
              </div>
              <div className="flex items-center gap-2">
                <div 
                  className="w-2 h-2 rounded-full animate-pulse"
                  style={{ backgroundColor: colors.accent }}
                ></div>
                <span className="text-xs font-semibold">Same Day Service</span>
              </div>
            </div>
          </div>
        </section>


        <Suspense fallback={<div className="py-16 text-center"><div className="animate-spin rounded-full h-8 w-8 border-b-2 mx-auto border-pink-500"></div></div>}>
          <GuaranteeSection />
        </Suspense>
        
        <Suspense fallback={<div className="py-16 text-center"><div className="animate-spin rounded-full h-8 w-8 border-b-2 mx-auto border-pink-500"></div></div>}>
          <TestimonialsSection />
        </Suspense>
        
        {/* <BookingSection /> */}

        <section 
          className="py-16 relative overflow-hidden"
          style={{
            background: `linear-gradient(135deg, ${colors.gradient.from}, ${colors.gradient.to})`
          }}
        >
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-10 left-10 w-20 h-20 rounded-full animate-pulse" style={{ backgroundColor: colors.accent }}></div>
            <div className="absolute bottom-10 right-10 w-16 h-16 rounded-full animate-pulse" style={{ animationDelay: '1s', backgroundColor: colors.primaryButton.bg }}></div>
            <div className="absolute top-1/2 left-1/3 w-12 h-12 rounded-full animate-pulse" style={{ animationDelay: '2s', backgroundColor: colors.accent }}></div>
          </div>

          <div className="container mx-auto px-4 sm:px-8 lg:px-16 text-center relative z-10">
            
            {/* Section Header */}
            <div className="mb-8">
              <h2 className="text-lg sm:text-xl md:text-2xl font-bold text-white mb-4 max-w-2xl mx-auto leading-tight">
                {getCTAContent(3).title}
              </h2>
              <p className="text-xs sm:text-sm text-white/90 max-w-2xl mx-auto leading-relaxed">
                {getCTAContent(3).description}
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
              
              {/* Call Button */}
              <a
                href={`tel:${phoneNumber}`}
                className="group relative inline-flex items-center gap-3 px-6 py-4 rounded-xl font-semibold text-base transition-all duration-300 hover:-translate-y-1 shadow-lg"
                style={{
                  backgroundColor: colors.primaryButton.bg,
                  color: colors.primaryButton.text
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = colors.primaryButton.hover}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = colors.primaryButton.bg}
              >
                <div className="relative">
                  <Phone className="w-5 h-5" />
                  <div className="absolute -top-1 -right-1 w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                </div>
                <div className="text-left">
                  <div className="text-xs font-semibold opacity-90 uppercase tracking-wide">Emergency Call</div>
                  <div className="text-sm font-bold">{phoneNumber}</div>
                </div>
              </a>

              {/* Book Online Button */}
              <Link
                to="/contact"
                className="group relative inline-flex items-center gap-3 px-6 py-4 rounded-xl font-semibold text-base transition-all duration-300 hover:-translate-y-1 shadow-lg backdrop-blur-md"
                style={{
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  color: colors.primaryButton.bg,
                  border: `2px solid ${colors.primaryButton.bg}30`
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = colors.primaryButton.bg;
                  e.currentTarget.style.color = colors.primaryButton.text;
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.95)';
                  e.currentTarget.style.color = colors.primaryButton.bg;
                }}
              >
                <Calendar className="w-5 h-5" />
                <div className="text-left">
                  <div className="text-xs font-semibold opacity-90 uppercase tracking-wide">Book Online</div>
                  <div className="text-sm font-bold">Schedule Service</div>
                </div>
              </Link>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap justify-center gap-6 text-white/90">
              <div className="flex items-center gap-2">
                <div 
                  className="w-2 h-2 rounded-full animate-pulse"
                  style={{ backgroundColor: colors.accent }}
                ></div>
                <span className="text-xs font-semibold">24/7 Available</span>
              </div>
              <div className="flex items-center gap-2">
                <div 
                  className="w-2 h-2 rounded-full animate-pulse"
                  style={{ backgroundColor: colors.primaryButton.bg }}
                ></div>
                <span className="text-xs font-semibold">Licensed & Insured</span>
              </div>
              <div className="flex items-center gap-2">
                <div 
                  className="w-2 h-2 rounded-full animate-pulse"
                  style={{ backgroundColor: colors.accent }}
                ></div>
                <span className="text-xs font-semibold">Same Day Service</span>
              </div>
            </div>
          </div>
        </section>
        <AreasSection />
        <FAQSection />
        <Footer />
      </div>
    </HelmetProvider>
  );
};

export default Index;
